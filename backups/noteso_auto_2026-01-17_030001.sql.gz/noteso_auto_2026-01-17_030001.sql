mysqldump: [Warning] Using a password on the command line interface can be insecure.
-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: noteso
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `two_factor_verified_at` datetime DEFAULT NULL,
  `backup_codes` json DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('super_admin','admin','editor','viewer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `invited_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `permissions` json DEFAULT NULL COMMENT 'Array de permissions',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login_at` datetime DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_admins_email` (`email`),
  KEY `idx_admins_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES ('admin_1','contact@obierti.fr','$2y$12$jUQUeW5lQO/EdLsB1fIkAOcaEsfsllFdtF0uPM8e/ZKenmRbbwRYi','AT75ADMXEGOUW6RZ',1,'2026-01-12 12:54:06','[\"E175-BD59\", \"D0F6-D256\", \"5D1E-620F\", \"3D35-59ED\", \"33C9-045C\", \"381E-308C\", \"141D-9945\", \"9D3D-FEE9\"]','Admin','Principal','super_admin',NULL,1,'[\"all\"]','2026-01-12 10:36:31','2026-01-16 15:50:15',NULL,'90.14.222.141',NULL);
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('online','offline','maintenance','error') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'online',
  `color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT '#3b82f6' COMMENT 'Couleur hex',
  `api_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `webhook_secret` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` json DEFAULT NULL COMMENT 'currency, timezone, etc.',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sites_api_key` (`api_key`),
  KEY `idx_sites_status` (`status`),
  KEY `idx_sites_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES ('site_t8732h4fee641e','comptael','https://comptael.fr','online','#ec4899','ek_t8732hfcbbe149','654ffe2884b3c6a06e679378b7a1ad80','{\"currency\": \"EUR\", \"timezone\": \"Europe/Paris\"}','2026-01-01 17:56:41','2026-01-12 11:42:56'),('site_t873s2dc8ee6fd','fusionel','https://fusionel.fr','online','#a855f7','ek_t873s2b29b750d','04c94ef01edc855b63a0556444f08f6b','{\"currency\": \"EUR\", \"timezone\": \"Europe/Paris\"}','2026-01-01 18:12:02','2026-01-12 11:42:56'),('site_t874jzde56096f','gestionnel association','https://gestionnel.com','online','#f97316','ek_t874jz91b66600','e8ce10501ce1839d87fd3e853d9f567c','{\"currency\": \"EUR\", \"timezone\": \"Europe/Paris\"}','2026-01-01 18:28:47','2026-01-12 11:42:56'),('site_t874n0058b4b23','gestionnel immo','httpd://gestionnel.fr','online','#f97316','ek_t874n0f6fddf2f','7bccace535d2cb5e0f8794f2c4cdc12b','{\"currency\": \"EUR\", \"timezone\": \"Europe/Paris\"}','2026-01-01 18:30:36','2026-01-12 11:42:56'),('site_t875nv1d114d60','offrel','https://offrel.fr','online','#3b82f6','ek_t875nvc76d812a','3198fc3badfe5d0f54d223c2689ebc5b','{\"currency\": \"EUR\", \"timezone\": \"Europe/Paris\"}','2026-01-01 18:52:43','2026-01-12 11:42:56'),('site_t8awt55af747a0','Elnumis','https://elnumis.fr','online','#ec4899','ek_t8awt55cbf34c8','9e9aae14b21daeb6f510dfd3c5db7649','{\"currency\": \"EUR\", \"timezone\": \"Europe/Paris\"}','2026-01-03 19:31:53','2026-01-12 11:42:56'),('site_t8lxu90b26fc56','coiffurEl','https://coiffurel.fr','online','#06b6d4','ek_t8lxu97b24ff6e','694e122ea3719c82cb5d6fdc103bd954','{\"currency\": \"EUR\", \"timezone\": \"Europe/Paris\"}','2026-01-09 18:27:45','2026-01-12 11:42:56');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `external_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ID dans le système client',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_users_site_id` (`site_id`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_external_id` (`site_id`,`external_id`),
  FULLTEXT KEY `ft_users_search` (`email`,`name`),
  CONSTRAINT `fk_users_site` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('user_t8t9z2c93a9976','site_t8lxu90b26fc56',NULL,'LAERALISA275@GMAIL.COM','LISA LAERA','{\"source\": \"webhook\", \"status\": \"active\"}','2026-01-13 17:33:02',NULL),('user_t8wm8o5ba7571a','site_t8lxu90b26fc56',NULL,'dkassi44@yahoo.fr','Denise Kassi','{\"source\": \"webhook\", \"status\": \"active\"}','2026-01-15 12:50:48',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EUR',
  `status` enum('pending','completed','failed','refunded','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'stripe, paypal, etc.',
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'stripe, paypal, manual',
  `provider_fee` decimal(10,2) DEFAULT NULL,
  `net_amount` decimal(10,2) DEFAULT NULL,
  `external_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ID chez le provider',
  `metadata` json DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_payments_site_id` (`site_id`),
  KEY `idx_payments_user_id` (`user_id`),
  KEY `idx_payments_subscription_id` (`subscription_id`),
  KEY `idx_payments_status` (`status`),
  KEY `idx_payments_paid_at` (`paid_at`),
  KEY `idx_payments_external` (`external_id`),
  CONSTRAINT `fk_payments_site` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_payments_subscription` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_payments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','cancelled','expired','trial','past_due') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `billing_cycle` enum('monthly','yearly') COLLATE utf8mb4_unicode_ci DEFAULT 'monthly',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EUR',
  `interval_type` enum('day','week','month','year') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'month',
  `interval_count` tinyint unsigned NOT NULL DEFAULT '1',
  `trial_ends_at` datetime DEFAULT NULL,
  `current_period_start` datetime DEFAULT NULL,
  `current_period_end` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_subscriptions_site_id` (`site_id`),
  KEY `idx_subscriptions_user_id` (`user_id`),
  KEY `idx_subscriptions_status` (`status`),
  KEY `idx_subscriptions_plan` (`plan`),
  CONSTRAINT `fk_subscriptions_site` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_subscriptions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `site_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'signup, payment, login, etc.',
  `description` text COLLATE utf8mb4_unicode_ci,
  `metadata` json DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_activities_site_id` (`site_id`),
  KEY `idx_activities_user_id` (`user_id`),
  KEY `idx_activities_type` (`type`),
  KEY `idx_activities_created_at` (`created_at`),
  CONSTRAINT `fk_activities_site` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_activities_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES ('act_t8t9z25dcc967c','site_t8lxu90b26fc56','user_t8t9z2c93a9976','signup','Nouvelle inscription: LAERALISA275@GMAIL.COM',NULL,'2026-01-13 17:33:02'),('act_t8wm8o70075a5c','site_t8lxu90b26fc56','user_t8wm8o5ba7571a','signup','Nouvelle inscription: dkassi44@yahoo.fr',NULL,'2026-01-15 12:50:48');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'NULL = tous les admins',
  `type` enum('info','success','warning','error') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_admin_id` (`admin_id`),
  KEY `idx_notifications_is_read` (`is_read`),
  KEY `idx_notifications_created_at` (`created_at`),
  CONSTRAINT `fk_notifications_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('notif_1',NULL,'info','Bienvenue!','Votre dashboard est prêt.',0,NULL,'2026-01-12 10:36:31'),('notif_2',NULL,'success','Nouveau record!','Vous avez dépassé 10 000 utilisateurs.',0,NULL,'2026-01-12 09:36:31'),('notif_t8r1zi7397cc39',NULL,'success','Rapport généré','Le rapport a été créé.',0,NULL,'2026-01-12 12:45:18'),('notif_t8r1zo857c6365',NULL,'success','Rapport généré','Le rapport a été créé.',0,NULL,'2026-01-12 12:45:24'),('notif_t8r1zu7137a336',NULL,'success','Rapport généré','Le rapport a été créé.',0,NULL,'2026-01-12 12:45:30'),('notif_t8t9z247f229e9',NULL,'info','Nouvel utilisateur','LAERALISA275@GMAIL.COM sur coiffurEl',0,NULL,'2026-01-13 17:33:02'),('notif_t8wm8obbddb20d',NULL,'info','Nouvel utilisateur','dkassi44@yahoo.fr sur coiffurEl',0,NULL,'2026-01-15 12:50:48');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `admin_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` enum('light','dark','system') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dark',
  `language` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fr',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EUR',
  `timezone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Europe/Paris',
  `notifications_email` tinyint(1) NOT NULL DEFAULT '1',
  `notifications_push` tinyint(1) NOT NULL DEFAULT '1',
  `integrations` json DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`admin_id`),
  CONSTRAINT `fk_settings_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('admin_1','dark','fr','EUR','Europe/Paris',1,1,'{\"paypal\": {\"enabled\": false, \"clientId\": \"\"}, \"stripe\": {\"apiKey\": \"\", \"enabled\": false}}',NULL);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_keys` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SHA256 hash de la clé',
  `key_prefix` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Préfixe pour identification (pk_xxx)',
  `permissions` json DEFAULT NULL COMMENT 'Liste des permissions',
  `rate_limit` int unsigned NOT NULL DEFAULT '1000' COMMENT 'Requêtes par heure',
  `allowed_origins` json DEFAULT NULL COMMENT 'Domaines autorisés CORS',
  `last_used_at` datetime DEFAULT NULL,
  `usage_count` bigint unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_api_keys_prefix` (`key_prefix`),
  KEY `idx_api_keys_admin` (`admin_id`),
  KEY `idx_api_keys_active` (`is_active`),
  CONSTRAINT `fk_api_keys_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
INSERT INTO `api_keys` VALUES ('apikey_t8r8jy9bb21f71','admin_1','Obierti','5671fc7933a00d1a886bae0815ebdeb324fd22223eb2bff0d2eb8ff0327dd8e2','pk_7aaedaa','[\"read\", \"write\"]',1000,'[]',NULL,0,0,NULL,'2026-01-12 14:07:10');
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_events`
--

DROP TABLE IF EXISTS `security_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'login, logout, 2fa_enabled, etc.',
  `severity` enum('info','warning','critical') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown',
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` json DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_security_events_admin` (`admin_id`),
  KEY `idx_security_events_type` (`event_type`),
  KEY `idx_security_events_severity` (`severity`),
  KEY `idx_security_events_created` (`created_at`),
  KEY `idx_security_events_ip` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_events`
--

LOCK TABLES `security_events` WRITE;
/*!40000 ALTER TABLE `security_events` DISABLE KEYS */;
INSERT INTO `security_events` VALUES (1,'admin_1','2fa_disable_failed','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Tentative de désactivation 2FA avec mauvais mot de passe\"}','2026-01-12 13:00:36'),(2,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-12 13:00:45'),(3,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-12 13:01:46'),(4,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-12 13:03:01'),(5,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-12 13:03:14'),(6,'admin_1','2fa_validation_failed','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Tentative de validation 2FA échouée\"}','2026-01-12 13:14:59'),(7,NULL,'logout','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Déconnexion\"}','2026-01-12 13:15:17'),(8,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-12 13:15:24'),(9,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-12 13:15:36'),(10,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-12 14:46:25'),(11,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-12 14:46:40'),(12,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-12 14:47:01'),(13,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-12 14:47:22'),(14,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-12 14:47:39'),(15,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-13 20:23:58'),(16,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-13 20:24:16'),(17,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-13 20:24:31'),(18,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-13 20:24:46'),(19,NULL,'login_failed','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0',NULL,'{\"message\": \"Échec connexion: contact@noteso.fr\"}','2026-01-13 20:24:59'),(20,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-13 20:25:07'),(21,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-13 20:25:18'),(22,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-13 20:25:27'),(23,NULL,'login_failed','info','90.14.222.141','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',NULL,'{\"message\": \"Échec connexion: contact@obierti.fr\"}','2026-01-14 09:25:15'),(24,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-14 09:25:22'),(25,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-14 09:25:39'),(26,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-14 16:06:26'),(27,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-14 16:06:40'),(28,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-15 10:05:04'),(29,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-15 10:05:32'),(30,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-15 10:05:39'),(31,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-15 23:21:51'),(32,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-15 23:22:13'),(33,NULL,'logout','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Déconnexion\"}','2026-01-15 23:23:10'),(34,'admin_1','login_2fa_required','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion nécessite 2FA: contact@obierti.fr\"}','2026-01-15 23:23:14'),(35,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-15 23:23:28'),(36,'admin_1','2fa_validation_success','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Validation 2FA réussie\"}','2026-01-15 23:23:36'),(37,'admin_1','login','info','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'{\"message\": \"Connexion réussie\"}','2026-01-16 15:50:15');
/*!40000 ALTER TABLE `security_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown',
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `request_method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_uri` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_logs_admin` (`admin_id`),
  KEY `idx_audit_logs_action` (`action`),
  KEY `idx_audit_logs_entity` (`entity_type`,`entity_id`),
  KEY `idx_audit_logs_created` (`created_at`),
  KEY `idx_audit_logs_ip` (`ip_address`),
  CONSTRAINT `fk_audit_logs_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alerts`
--

DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alerts` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `metric` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'revenue, users, payments, churn, etc.',
  `condition` enum('above','below','equals','change_percent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `threshold` decimal(15,2) NOT NULL,
  `time_window` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'daily' COMMENT 'hourly, daily, weekly, monthly',
  `site_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'NULL = tous les sites',
  `notify_email` tinyint(1) NOT NULL DEFAULT '1',
  `notify_slack` tinyint(1) NOT NULL DEFAULT '0',
  `notify_discord` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `last_triggered_at` datetime DEFAULT NULL,
  `trigger_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `rule_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Alerte',
  `message` text COLLATE utf8mb4_unicode_ci,
  `severity` enum('info','warning','critical') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'warning',
  `is_resolved` tinyint(1) NOT NULL DEFAULT '0',
  `resolved_at` datetime DEFAULT NULL,
  `resolved_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_alerts_admin` (`admin_id`),
  KEY `idx_alerts_metric` (`metric`),
  KEY `idx_alerts_active` (`is_active`),
  CONSTRAINT `fk_alerts_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alerts`
--

LOCK TABLES `alerts` WRITE;
/*!40000 ALTER TABLE `alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_rules`
--

DROP TABLE IF EXISTS `alert_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_rules` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'threshold',
  `metric` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `condition_operator` enum('>','<','>=','<=','==','!=') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '>',
  `condition_value` decimal(15,2) NOT NULL,
  `time_window_minutes` int unsigned NOT NULL DEFAULT '5',
  `severity` enum('info','warning','critical') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'warning',
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `notify_email` tinyint(1) NOT NULL DEFAULT '1',
  `notify_webhook` tinyint(1) NOT NULL DEFAULT '0',
  `webhook_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cooldown_minutes` int unsigned NOT NULL DEFAULT '15',
  `last_triggered_at` datetime DEFAULT NULL,
  `trigger_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_alert_rules_type` (`type`),
  KEY `idx_alert_rules_metric` (`metric`),
  KEY `idx_alert_rules_enabled` (`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_rules`
--

LOCK TABLES `alert_rules` WRITE;
/*!40000 ALTER TABLE `alert_rules` DISABLE KEYS */;
INSERT INTO `alert_rules` VALUES ('rule_api_500','Trafic API élevé','Plus de 500 requêtes par minute','threshold','requests_per_minute','>',500.00,1,'warning',1,1,0,NULL,15,NULL,0,'2026-01-16 14:35:33',NULL),('rule_login_fail_20','Attaque force brute','Plus de 20 échecs de connexion en 5 minutes','threshold','login_failures','>',20.00,5,'critical',1,1,0,NULL,15,NULL,0,'2026-01-16 14:35:33',NULL),('rule_login_fail_5','Échecs de connexion (5+)','Plus de 5 échecs de connexion en 5 minutes','threshold','login_failures','>',5.00,5,'warning',1,1,0,NULL,15,NULL,0,'2026-01-16 14:35:33',NULL);
/*!40000 ALTER TABLE `alert_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_rules`
--

DROP TABLE IF EXISTS `ip_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_rules` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('whitelist','blacklist') COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ip_rules_type` (`type`),
  KEY `idx_ip_rules_ip` (`ip_address`),
  KEY `idx_ip_rules_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_rules`
--

LOCK TABLES `ip_rules` WRITE;
/*!40000 ALTER TABLE `ip_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `device_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` enum('desktop','mobile','tablet','unknown') COLLATE utf8mb4_unicode_ci DEFAULT 'unknown',
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `is_current` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sessions_token` (`token`),
  KEY `idx_sessions_admin_id` (`admin_id`),
  KEY `idx_sessions_expires_at` (`expires_at`),
  CONSTRAINT `fk_sessions_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('sess_9a6b41dd467a39e4','admin_1','9a8ba5df3c77907ba7f637d2c3985caf4a91c8069bc427b9fc9965b26c72f4be','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'unknown',NULL,NULL,0,'2026-01-15 21:43:51','2026-01-22 21:43:51'),('sess_t8plia63403e84','admin_1','de1c269e1b52580a747acc1feb5380678fd61fe0e59602c01bdf7a4ba573a697','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'unknown',NULL,NULL,0,'2026-01-11 17:51:46','2026-01-18 17:51:46'),('sess_t8r1wq28ea40cd','admin_1','117a7a5476166a47ee9f092e6ee86dedc00b221155ed9f23d3aad7750390432f','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-12 12:43:38',1,'2026-01-12 12:43:38','2026-01-19 12:43:38'),('sess_t8r2p965f2e33e','admin_1','77a558c13633a986adc5e036c3407cb79611a1998fca9cbc2560708971669c84','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-12 13:00:45',0,'2026-01-12 13:00:45','2026-01-19 13:00:45'),('sess_t8r2qy02743e26','admin_1','65a6d23ddef94fc431f53cf4afd480e44d7366b9705c21debfa024c08d76c072','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-12 13:01:46',0,'2026-01-12 13:01:46','2026-01-19 13:01:46'),('sess_t8r3doe4136854','admin_1','d44d3a18b0e97c14f3ce68c71fbab0869ea9d05a148e2d373ca81cb32f9b7f9a','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-12 13:15:24',1,'2026-01-12 13:15:24','2026-01-19 13:15:24'),('sess_t8r7ld5d128a08','admin_1','2ad0cbf5b3f640fef1da916313a0eb8051182df8b4520e6724f87d5ae528bd74','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-12 14:46:25',0,'2026-01-12 14:46:25','2026-01-19 14:46:25'),('sess_t8r7ls2805b869','admin_1','56870f7dc7a3f8485f48b34f02bd36704515d4e8ee2ce8d6db786d75555f9239','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-12 14:46:40',0,'2026-01-12 14:46:40','2026-01-19 14:46:40'),('sess_t8r7mddca94738','admin_1','26f8edb9fc19f8ecd7cf7e283676d9a74edcc4937cf04d9678f20ab613343a82','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-12 14:47:01',0,'2026-01-12 14:47:01','2026-01-19 14:47:01'),('sess_t8r7mye5245e87','admin_1','353e82d0cfc6cfd4a69cc2e3fc70c9d931fcba9ae46fd1e49bf04e08de94914f','90.14.222.141','Mozilla/5.0 (X11; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-12 14:47:22',1,'2026-01-12 14:47:22','2026-01-19 14:47:22'),('sess_t8thvy9a7bf305','admin_1','29c90922c5c9eb423ae2ae19fc411df295ef65034b0887a70ff4a422f9cb503d','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0','Linux','desktop',NULL,'2026-01-13 20:23:58',0,'2026-01-13 20:23:58','2026-01-20 20:23:58'),('sess_t8thwg67e0ecf4','admin_1','8581f5f4427ab6ebd8f94eac8f0827138088ca8624ba797483fa154dd391e0c2','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0','Linux','desktop',NULL,'2026-01-13 20:24:16',0,'2026-01-13 20:24:16','2026-01-20 20:24:16'),('sess_t8thwvb59fdea3','admin_1','90a3fdfff4912c06b724c9c03a9fba39c7aa32e82c6ad4f9c8494eef70b50de6','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0','Linux','desktop',NULL,'2026-01-13 20:24:31',0,'2026-01-13 20:24:31','2026-01-20 20:24:31'),('sess_t8thxa4ebefc3e','admin_1','41c65a5e001f57bf01e107f883de1cd148ff23b2ef2f61fa826b0bfda28988c4','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0','Linux','desktop',NULL,'2026-01-13 20:24:46',0,'2026-01-13 20:24:46','2026-01-20 20:24:46'),('sess_t8thxv697e264b','admin_1','51d49b9169cb497679771a6e7ecaf9e5b0e4af3540b7a40ccfb4f05c0f01538e','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0','Linux','desktop',NULL,'2026-01-13 20:25:07',0,'2026-01-13 20:25:07','2026-01-20 20:25:07'),('sess_t8thy6797df20b','admin_1','9f80f40819271394482c6187a6494ff6457f832507e026056d206bd304cd1f79','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:143.0) Gecko/20100101 Firefox/143.0','Linux','desktop',NULL,'2026-01-13 20:25:18',1,'2026-01-13 20:25:18','2026-01-20 20:25:18'),('sess_t8ui2a90c66066','admin_1','54f45e77c0fda8a0a83308eab19a2f77b0b30df30884b567f18467456ad0501b','90.14.222.141','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0','Windows','desktop',NULL,'2026-01-14 09:25:22',1,'2026-01-14 09:25:22','2026-01-21 09:25:22'),('sess_t8v0mq4e674cd9','admin_1','1f45d12334f51788c04eefc692d30f8f32dd632bff3808067cb81d223b351904','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-14 16:06:26',1,'2026-01-14 16:06:26','2026-01-21 16:06:26'),('sess_t8wekgadff5d95','admin_1','66f3f45885468635704d4dd966bab5aa28dfd02ead6bbd55870da56a06e1bfbb','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-15 10:05:04',0,'2026-01-15 10:05:04','2026-01-22 10:05:04'),('sess_t8wel87a9a77b8','admin_1','21a55d6a72eee2639caac47eeac7bc04afea993c109ca804102237ba191ed22f','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-15 10:05:32',1,'2026-01-15 10:05:32','2026-01-22 10:05:32'),('sess_t8xfiqf1729540','admin_1','a356dca18c854a62144d7f5a43c811fe8a14a39b93a73f25718177021f1ddbbf','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0','Linux','desktop',NULL,'2026-01-15 23:23:14',1,'2026-01-15 23:23:14','2026-01-22 23:23:14'),('sess_t8yp7r78ba90d6','admin_1','f9b3fc1af1f832c9eef747999604b2f142a1928a604b8522623691a830344201','90.14.222.141','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:146.0) Gecko/20100101 Firefox/146.0',NULL,'unknown',NULL,NULL,0,'2026-01-16 15:50:15','2026-01-23 15:50:15');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-17  3:00:01
